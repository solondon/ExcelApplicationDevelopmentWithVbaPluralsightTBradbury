About the Workbook
------------------
This is a preliminary demo workbook for module 2 of Excel Application Development with VBA.

This demo file is a pared-down version of the entire Common Code Library that will be made available to plus subscribers. Later modules will add to this starter workbook.

About the .ini File
-------------------
The .ini file that is included is for use with MZ-Tools (www.mz-tools.com).

After MZ-Tools has been installed and run the first time, it will generate its own .ini file (usually located in C:\Users\<UserName>\AppData\Roaming\MZTools Software\MZTools3). Simply drop this file into that folder, replacing the one MZ-Tools generated.
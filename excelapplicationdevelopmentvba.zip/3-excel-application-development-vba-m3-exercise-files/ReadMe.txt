About the Workbook
------------------
This is a preliminary demo workbook for module 3 of Excel Application Development with VBA. This is compiled under Office 2013. The final will use Office 2007 to ensure compatibility.

This demo file is a pared-down version of the entire Common Code Library that will be made available to plus subscribers. Later modules will add to this starter workbook.
